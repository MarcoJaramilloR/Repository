﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int edad = 19;
            int tel = 0943243245;
            double estatura = 70.5;
            float familia = 5;
            bool condicion = true;
            char Sexo = 'M';
            string nombre = "Marco";
            object deporte = "Futbol" ;
            Console.WriteLine("-------------------Datos Personales-------------------");
            Console.WriteLine("Nombre : " + nombre);
            Console.WriteLine("Teléfono : " + tel);
            Console.WriteLine("Edad : " + edad);
            Console.WriteLine("Sexo : " + Sexo);

            if (condicion)
            {
                Console.WriteLine("Estado Activo");
            }
            else
            {
                Console.WriteLine("Estado No Activo");
            }
            Console.WriteLine("Deporte favorito: "+ deporte);
            Console.WriteLine("Estatura: "+ estatura + " cm");
            Console.WriteLine("Número de familiares: "+ familia );

            Console.WriteLine("-------------------Estructuras de control y repetitivas-------------------");
            int ed = 35;
            int contador1 = 0;
            int contador2 = 0;
            Console.WriteLine("Estructura if, else");
            if (ed >= 18)
            {
                Console.WriteLine("Es mayor de edad");
            }
            else
            {
                Console.WriteLine("Es menor de edad");
            }
            Console.WriteLine("Estructura while, do while");
            
            while (contador1 <= 5)
            {
                Console.WriteLine("while: " + contador1);
                contador1++;
            }
            
            do
            {
                Console.WriteLine("do while: " + contador2);
                contador2++;
            } while (contador2 <= 10);

            Console.WriteLine("Estructura For, foreach");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Iteración for: " + i);
            }
            Console.WriteLine("Estructura foreach");
            int[] numeros = { 1, 2, 3, 4 };
            foreach (int numero in numeros)
            {
                Console.WriteLine(numero);
            }
        }
    }
}
